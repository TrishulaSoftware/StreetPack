# Street Pack Foundry

Generated: 20260118_022341_Z
Version: 0.1.0

- repos/ contains per-tool repos
- install_all.sh installs tools into ~/.local/bin
- bootstrap/smoke_all.sh validates scripts
