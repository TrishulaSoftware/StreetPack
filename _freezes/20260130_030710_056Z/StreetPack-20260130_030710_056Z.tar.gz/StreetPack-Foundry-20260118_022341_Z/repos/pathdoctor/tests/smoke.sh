#!/usr/bin/env bash
set -euo pipefail
"../pathdoctor" --help >/dev/null
"../pathdoctor" --version >/dev/null
