#!/usr/bin/env bash
set -euo pipefail
"../packreceipt" --help >/dev/null
"../packreceipt" --version >/dev/null
