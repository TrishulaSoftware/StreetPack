#!/usr/bin/env bash
set -euo pipefail
"../dirscope" --help >/dev/null
"../dirscope" --version >/dev/null
