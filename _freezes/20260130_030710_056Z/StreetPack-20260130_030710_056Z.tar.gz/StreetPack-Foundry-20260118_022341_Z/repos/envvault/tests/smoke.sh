#!/usr/bin/env bash
set -euo pipefail
"../envvault" --help >/dev/null
"../envvault" --version >/dev/null
