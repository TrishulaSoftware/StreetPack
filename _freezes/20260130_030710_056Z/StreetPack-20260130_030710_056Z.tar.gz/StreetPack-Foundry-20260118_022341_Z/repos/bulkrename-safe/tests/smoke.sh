#!/usr/bin/env bash
set -euo pipefail
"../bulkrename-safe" --help >/dev/null
"../bulkrename-safe" --version >/dev/null
