#!/usr/bin/env bash
set -euo pipefail
"../safedel" --help >/dev/null
"../safedel" --version >/dev/null
