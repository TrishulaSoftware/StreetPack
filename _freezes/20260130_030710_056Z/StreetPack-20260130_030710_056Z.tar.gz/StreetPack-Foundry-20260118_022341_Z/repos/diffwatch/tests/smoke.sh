#!/usr/bin/env bash
set -euo pipefail
"../diffwatch" --help >/dev/null
"../diffwatch" --version >/dev/null
