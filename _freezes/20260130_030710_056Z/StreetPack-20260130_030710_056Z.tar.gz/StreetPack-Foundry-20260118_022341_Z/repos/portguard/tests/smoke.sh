#!/usr/bin/env bash
set -euo pipefail
"../portguard" --help >/dev/null
"../portguard" --version >/dev/null
