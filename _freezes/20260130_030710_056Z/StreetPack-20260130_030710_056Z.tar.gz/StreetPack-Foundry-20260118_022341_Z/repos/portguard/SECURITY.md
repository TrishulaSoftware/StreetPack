Security: safe-by-default. No destructive behavior without explicit flags (MVP).
