#!/usr/bin/env bash
set -euo pipefail
"../logtail+" --help >/dev/null
"../logtail+" --version >/dev/null
