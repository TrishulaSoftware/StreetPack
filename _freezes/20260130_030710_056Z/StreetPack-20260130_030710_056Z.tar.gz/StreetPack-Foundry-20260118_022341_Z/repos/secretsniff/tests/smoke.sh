#!/usr/bin/env bash
set -euo pipefail
"../secretsniff" --help >/dev/null
"../secretsniff" --version >/dev/null
