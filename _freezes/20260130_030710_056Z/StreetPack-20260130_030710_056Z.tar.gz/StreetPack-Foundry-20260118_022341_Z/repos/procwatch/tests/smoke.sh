#!/usr/bin/env bash
set -euo pipefail
"../procwatch" --help >/dev/null
"../procwatch" --version >/dev/null
