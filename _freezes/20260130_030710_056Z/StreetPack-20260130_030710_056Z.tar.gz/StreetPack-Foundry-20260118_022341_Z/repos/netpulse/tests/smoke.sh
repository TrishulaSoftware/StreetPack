#!/usr/bin/env bash
set -euo pipefail
"../netpulse" --help >/dev/null
"../netpulse" --version >/dev/null
