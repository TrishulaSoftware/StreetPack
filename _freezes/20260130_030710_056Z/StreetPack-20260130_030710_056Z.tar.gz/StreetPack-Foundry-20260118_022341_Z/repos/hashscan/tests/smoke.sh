#!/usr/bin/env bash
set -euo pipefail
"../hashscan" --help >/dev/null
"../hashscan" --version >/dev/null
