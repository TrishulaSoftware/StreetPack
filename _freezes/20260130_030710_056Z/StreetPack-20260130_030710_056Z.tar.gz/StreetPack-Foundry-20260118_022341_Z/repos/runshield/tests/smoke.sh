#!/usr/bin/env bash
set -euo pipefail
"../runshield" --help >/dev/null
"../runshield" --version >/dev/null
