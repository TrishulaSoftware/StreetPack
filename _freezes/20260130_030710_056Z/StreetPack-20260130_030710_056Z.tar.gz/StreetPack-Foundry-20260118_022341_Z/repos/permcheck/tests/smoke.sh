#!/usr/bin/env bash
set -euo pipefail
"../permcheck" --help >/dev/null
"../permcheck" --version >/dev/null
