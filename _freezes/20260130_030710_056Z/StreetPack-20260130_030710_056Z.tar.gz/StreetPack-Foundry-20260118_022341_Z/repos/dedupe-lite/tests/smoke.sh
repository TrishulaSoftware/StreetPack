#!/usr/bin/env bash
set -euo pipefail
"../dedupe-lite" --help >/dev/null
"../dedupe-lite" --version >/dev/null
