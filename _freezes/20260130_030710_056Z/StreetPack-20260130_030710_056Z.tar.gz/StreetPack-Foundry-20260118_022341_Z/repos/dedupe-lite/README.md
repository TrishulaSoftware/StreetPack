# dedupe-lite

Street Pack tool (v0.1.0).

Try:
  dedupe-lite --help
