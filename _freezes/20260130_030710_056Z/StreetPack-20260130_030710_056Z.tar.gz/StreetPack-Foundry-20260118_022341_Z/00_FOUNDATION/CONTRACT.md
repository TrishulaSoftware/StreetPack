# Street Pack CLI Contract (MVP)

All tools support:
  --help
  --version
  --json
  --out <file>
  --receipt-dir <dir>

Default receipt dir:
  ~/.local/share/streetpack/receipts/<tool>/
